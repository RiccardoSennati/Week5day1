package com.riccardosennati.dayone

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstDayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstDayApplication.class, args);
		System.out.println("Ciao Mondo!!");
	}

}