package com.riccardosennati.dayone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstDayApplicationTests {

	@Test
	void contextLoads() {
	}

}
